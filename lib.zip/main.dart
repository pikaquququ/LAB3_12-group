import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_bindings.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_page.dart';
import 'package:ffpo_app/app/modules/home_module/binding.dart';
import 'package:ffpo_app/app/modules/home_module/view.dart';
import 'package:ffpo_app/app/modules/letter_receiving_detail_module/binding.dart';
import 'package:ffpo_app/app/modules/letter_receiving_detail_module/view.dart';
import 'package:ffpo_app/app/modules/letter_write_content_module/binding.dart';
import 'package:ffpo_app/app/modules/letter_write_content_module/view.dart';
import 'package:ffpo_app/app/modules/login_module/binding.dart';
import 'package:ffpo_app/app/modules/login_module/view.dart';
import 'package:ffpo_app/app/modules/start_module/binding.dart';
import 'package:ffpo_app/app/modules/start_module/view.dart';
import 'package:ffpo_app/app/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app/routes/app_pages.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //Set the fit size (Find your UI design, look at the dimensions of the device screen and fill it in,unit in dp)

    Get.put(FFPOController());

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive, overlays: [SystemUiOverlay.top]);
    return ScreenUtilInit(
      designSize: const Size(428, 926),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return GetMaterialApp(
            home: StartModulePage(),
            initialBinding: StartModuleBinding(),
            // initialRoute: "/",
            theme: appThemeData,
            defaultTransition: Transition.fade,
            builder: EasyLoading.init(),
            debugShowCheckedModeBanner: false,
            getPages: AppPages.pages);
      },
    );
  }
}
