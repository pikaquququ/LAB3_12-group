import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/data/model/mail_draft.dart';
import 'package:ffpo_app/app/data/model/stamp_detail.dart';
import 'package:ffpo_app/app/data/model/user_param.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiProvider {
  // static String serverIp = "10.0.2.2:51601";
  // static String serverIp = "172.20.10.7:51601";

  static String serverIp = "14.29.181.103:51601";

  // 192.168.31.245
  static Future<String?> getToken() async {
    return SharedPreferences.getInstance().then((sp) => sp.getString("token"));
  }

  static Future<dynamic> login(UserParam userParam) async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show();
    return await GetConnect(timeout: const Duration(seconds: 15)).post("http://$serverIp/user/login/login_auth", {
      "username": userParam.username,
      "password": userParam.password,
      "longitude": userParam.longitude,
      "latitude": userParam.latitude,
      "address": userParam.address,
      "phone": userParam.phone,
    }).then((resp) {
      EasyLoading.dismiss();
      if (resp.body["code"] == 2) {
        throw Exception([resp.body["errorMessage"]]);
      }
      return resp.body["data"];
    }).onError((error, stackTrace) {
      EasyLoading.dismiss();
      EasyLoading.showError("登录错误${error.toString()}");
    });
  }

  static Future<List<StampDetail>> getStamps() async {
    String? token = await getToken();
    if (token == null) return [];
    final ctl = Get.find<FFPOController>();
    return await GetConnect(timeout: Duration(seconds: 10)).post("http://$serverIp/stamp/user/list", {
      "size": 100,
      "page": 1,
      "orderWay": 1,
      "userId": ctl.user.id,
    }, headers: {
      "token": token
    }).then((resp) {
      List<dynamic> stampDetails = resp.body["data"];
      List<StampDetail> result = [];
      for (int i = 0; i < stampDetails.length; i++) {
        result.add(StampDetail.fromJson(stampDetails[i]));
      }
      return result;
    });
  }

  static Future<List<Mail>> getMails() async {
    String? token = await getToken();
    if (token == null) return [];
    final ctl = Get.find<FFPOController>();
    return await GetConnect(timeout: Duration(seconds: 10)).post("http://$serverIp/mail/api/list", {
      "userId": ctl.user.id,
      "bagType": 0,
      "page": 1,
      "size": 999,
    }, headers: {
      "token": token
    }).then((resp) {
      List<dynamic> mails = resp.body["data"];
      List<Mail> result = [];
      for (int i = 0; i < mails.length; i++) {
        result.add(Mail().fromJson(mails[i]));
      }
      return result;
    });
  }

  static Future<List<Mail>> elSearch(String tag) async {
    String? token = await getToken();
    if (token == null) return [];
    final ctl = Get.find<FFPOController>();
    return await GetConnect(timeout: Duration(seconds: 10)).post(
        "http://$serverIp/mail/api/search", {"searchWords": tag, "page": 1, "size": 100},
        headers: {"token": token}).then((resp) {
      List<dynamic> mails = resp.body["data"];
      List<Mail> result = [];
      for (int i = 0; i < mails.length; i++) {
        print(mails[i]);
        result.add(Mail().fromJson(mails[i]));
      }
      return result;
    });
  }

  static Future<String?> sendMail(MailDraft mailDraft) async {
    String? token = await getToken();
    if (token == null) return null;
    return await GetConnect(timeout: Duration(seconds: 10))
        .post("http://$serverIp/mail/api/send/id", mailDraft.toJson(), headers: {"token": token}).then((resp) {
      print(resp);
      dynamic data = resp.body["data"];
      return data["sendTime"];
    });
  }
}
