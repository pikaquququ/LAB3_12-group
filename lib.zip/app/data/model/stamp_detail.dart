class StampDetail {
  int? id;
  int? isLike;
  String? type;
  int? stampTypeId;
  double? life;
  String? signature;
  String? getTime;
  int? ownnerId;
  String? msg;
  String? name;
  String? level;
  String? img;

  StampDetail.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    isLike = json['isLike'];
    type = json['type'];
    stampTypeId = json['stampTypeId'];
    life = json['life'];
    signature = json['signature'];
    getTime = json['getTime'];
    ownnerId = json['ownnerId'];
    msg = json['msg'];
    name = json['name'];
    level = json['level'];
    img = json['img'];
  }

}
