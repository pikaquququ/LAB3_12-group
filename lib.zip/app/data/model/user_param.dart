class UserParam {
   String? username;
  late String password;
  late double longitude;
  late double latitude;
  late String address;
  late String phone;

  UserParam(this.username, this.password, this.longitude, this.latitude, this.address, this.phone);
}
