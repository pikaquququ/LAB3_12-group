class Mail {
  int? id;
  int? isSend;
  int? sendUserId;
  int? getUserId;
  int? stampId;
  String? msg;
  DateTime? creteTime;
  late DateTime sendTime;
  int? type;
  int? isDelete;
  String? stampImg;
  String? sendAdd;
  String? getAdd;
  int? userId;
  int? isLike;
  String? title;
  String? tags;
  int? likeNum;
  int? collectNum;
  int? isPublic;
  int? commentNum;
  String? sendUserName;

  fromJson(dynamic json) {
    id = json["id"];
    isSend = json["isSend"];
    // sendUserId = json["sendUserId"];
    stampId = json["stampId"];
    msg = json["msg"];
    type = json["type"];
    stampImg = json["stampImg"];
    sendAdd = json["sendAdd"];
    getAdd = json["getAdd"];
    userId = json["userId"];
    isLike = json["isLike"];
    title = json["title"];
    tags = json["tags"];
    likeNum = json["likeNum"];
    collectNum = json["collectNum"];
    isPublic = json["isPublic"];
    sendUserName = json["sendUserName"];
    commentNum = json["commentNum"];
    if (json["creteTime"] != null) {
      creteTime = DateTime.parse(json["creteTime"]);
    }
    sendTime = DateTime.parse(json["sendTime"] ?? DateTime.now().toString());
    return this;
  }
}
