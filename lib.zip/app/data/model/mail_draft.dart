class MailDraft {
  int? sendUserId;
  int? stampId;
  String? msg;
  String? title;
  int? getUserId;
  int? isPublic;
  String? id;

  MailDraft({this.sendUserId, this.stampId, this.msg, this.title, this.getUserId, this.isPublic, this.id});

  MailDraft.fromJson(Map<String, dynamic> json) {
    sendUserId = json['sendUserId'];
    stampId = json['stampId'];
    msg = json['msg'];
    title = json['title'];
    getUserId = json['getUserId'];
    isPublic = json['isPublic'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sendUserId'] = this.sendUserId;
    data['stampId'] = this.stampId;
    data['msg'] = this.msg;
    data['title'] = this.title;
    data['getUserId'] = this.getUserId;
    data['isPublic'] = this.isPublic;
    data['id'] = this.id;
    return data;
  }
}
