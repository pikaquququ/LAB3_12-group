class User {
  int? id;
  String? username;
  int? stampNum;
  int? stampMaxNum;
  String? password;
  int? sex;
  int? level;
  String? headImg;
  String? signature;
  String? address;
  int? coinNum;
  int? age;
  int? stampBagId;
  String? salt;
  String? longitude;
  String? latitude;
  String? phone;
  DateTime? creteTime;
  DateTime? updateTime;
  DateTime? lastLoginTime;

  fromJson(dynamic json) {
    id = json["id"];
    username = json["username"];
    stampNum = json["stampNum"];
    stampMaxNum = json["stampMaxNum"];
    password = json["password"];
    sex = json["sex"];
    level = json["level"];
    headImg = json["headImg"];
    signature = json["signature"];
    address = json["address"];
    coinNum = json["coinNum"];
    age = json["age"];
    stampBagId = json["stampBagId"];
    salt = json["salt"];
    longitude = json["longitude"];
    latitude = json["latitude"];
    phone = json["phone"];
    return this;
  }
}
