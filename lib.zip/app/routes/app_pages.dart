import 'package:ffpo_app/app/modules/home_module/binding.dart';
import 'package:ffpo_app/app/modules/home_module/view.dart';
import 'package:ffpo_app/app/modules/letter_receiving_detail_module/binding.dart';
import 'package:ffpo_app/app/modules/letter_receiving_detail_module/view.dart';
import 'package:ffpo_app/app/modules/letter_write_content_module/binding.dart';
import 'package:ffpo_app/app/modules/letter_write_content_module/view.dart';
import 'package:ffpo_app/app/modules/letter_write_stamp_module/binding.dart';
import 'package:ffpo_app/app/modules/letter_write_stamp_module/view.dart';
import 'package:ffpo_app/app/modules/login_module/binding.dart';
import 'package:ffpo_app/app/modules/login_module/view.dart';
import 'package:ffpo_app/app/modules/penpal_module/view.dart';
import 'package:ffpo_app/app/modules/register_module/binding.dart';
import 'package:ffpo_app/app/modules/register_module/view.dart';
import 'package:ffpo_app/app/modules/retrieve_password_module/binding.dart';
import 'package:ffpo_app/app/modules/retrieve_password_module/view.dart';
import 'package:ffpo_app/app/modules/search_module/binding.dart';
import 'package:ffpo_app/app/modules/search_module/view.dart';
import 'package:ffpo_app/app/modules/settings_module/binding.dart';
import 'package:ffpo_app/app/modules/settings_module/view.dart';
import 'package:ffpo_app/app/modules/stamps_module/binding.dart';
import 'package:ffpo_app/app/modules/stamps_module/view.dart';
import 'package:ffpo_app/app/modules/start_module/binding.dart';
import 'package:ffpo_app/app/modules/start_module/view.dart';
import 'package:ffpo_app/app/modules/user_info_module/binding.dart';
import 'package:ffpo_app/app/modules/user_info_module/view.dart';

import '../../app/modules/f_f_p_o_module/f_f_p_o_bindings.dart';
import '../../app/modules/f_f_p_o_module/f_f_p_o_page.dart';
import 'package:get/get.dart';

part './app_routes.dart';
/**
 * GetX Generator - fb.com/htngu.99
 * */

abstract class AppPages {
  static final pages = [
    GetPage(
      name: Routes.FFPO,
      page: () => FFPOPage(),
      binding: FFPOBinding(),
    ),
    GetPage(
      name: Routes.START,
      page: () => StartModulePage(),
      binding: StartModuleBinding(),
    ),
    GetPage(
      name: Routes.REGISTER,
      page: () => RegisterModulePage(),
      binding: RegisterModuleBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.LOGIN,
      page: () => LoginModulePage(),
      binding: LoginModuleBinding(),
    ),
    GetPage(
      name: Routes.LETTER_SENDING_DETAIL,
      page: () => LoginModulePage(),
      binding: LoginModuleBinding(),
    ),
    GetPage(
      name: Routes.LETTER_WRITE_CONTENT,
      page: () => LetterWriteContentModulePage(),
      binding: LetterWriteContentModuleBinding(),
    ),
    GetPage(
      name: Routes.LETTER_WRITE_STAMP,
      page: () => LetterWriteStampModulePage(),
      binding: LetterWriteStampModuleBinding(),
    ),
    GetPage(
      name: Routes.RETRIEVE_PASSWORD,
      page: () => RetrievePasswordModulePage(),
      binding: RetrievePasswordModuleBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.STAMP_COLLECTION,
      page: () => LoginModulePage(),
      binding: LoginModuleBinding(),
    ),
    GetPage(
      name: Routes.LETTER_RECEIVING_DETAIL,
      page: () => LetterReceivingDetailModulePage(),
      binding: LetterReceivingDetailModuleBinding(),
    ),
    GetPage(
      name: Routes.SEARCH,
      page: () => SearchModulePage(),
      binding: SearchModuleBinding(),
    ),
  ];
}
