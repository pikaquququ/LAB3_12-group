part of './app_pages.dart';
/**
 * GetX Template Generator - fb.com/htngu.99
 * */

abstract class Routes {
  static const FFPO = '/f_f_p_o'; // FFPO page
  static const START = '/start';
  static const REGISTER = '/register';
  static const LOGIN = '/login';
  static const HOME = '/home';
  static const RETRIEVE_PASSWORD = "/retrieve_password";
  static const LETTER_RECEIVING_DETAIL = '/letter_receiving_detail';

  static const LETTER_SENDING_DETAIL = '/letter_sending_detail';
  static const LETTER_WRITE_CONTENT = '/letter_write_content';
  static const LETTER_WRITE_STAMP = '/letter_write_stamp';
  static const MINE = '/mine';
  static const PENPAL = '/penpal';
  static const STAMPS = '/stamps';
  static const USERINFO = '/userinfo';

  static const STAMP_COLLECTION = '/stamp_collection'; // LetterWriteModule page
static const SETTINGS = 'settings';

  static const NOTIFICATION_MANAGER = 'notification_manager';
  static const MARKS = 'marks';
  static const STAMPS_STORE = 'stamps_store';
  static const SEARCH = '/search';

}
