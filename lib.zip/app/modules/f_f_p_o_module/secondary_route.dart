import 'package:get/get.dart';

import '../home_module/binding.dart';
import '../home_module/view.dart';

Map<String,GetPageRoute> SecondaryRoutes = {
  "": GetPageRoute(page: () =>  const HomeModulePage(), binding: HomeModuleBinding(), transition: Transition.fadeIn),
};
