import 'package:ffpo_app/app/modules/home_module/binding.dart';
import 'package:ffpo_app/app/modules/home_module/view.dart';
import 'package:ffpo_app/app/modules/letter_receiving_detail_module/binding.dart';
import 'package:ffpo_app/app/modules/letter_receiving_detail_module/view.dart';
import 'package:ffpo_app/app/modules/marks_module/binding.dart';
import 'package:ffpo_app/app/modules/menu_module/view.dart';
import 'package:ffpo_app/app/modules/notification_manager_module/binding.dart';
import 'package:ffpo_app/app/modules/notification_manager_module/view.dart';
import 'package:ffpo_app/app/modules/penpal_module/binding.dart';
import 'package:ffpo_app/app/modules/penpal_module/view.dart';
import 'package:ffpo_app/app/modules/settings_module/binding.dart';
import 'package:ffpo_app/app/modules/settings_module/view.dart';
import 'package:ffpo_app/app/modules/stamps_module/binding.dart';
import 'package:ffpo_app/app/modules/stamps_module/view.dart';
import 'package:ffpo_app/app/modules/stamps_store_module/binding.dart';
import 'package:ffpo_app/app/modules/stamps_store_module/view.dart';
import 'package:ffpo_app/app/modules/user_info_module/binding.dart';
import 'package:ffpo_app/app/modules/user_info_module/view.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_zoom_drawer/flutter_zoom_drawer.dart';
import 'package:get/get.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';

import '../marks_module/view.dart';

Map<String, dynamic> routes = {
  "/": () => GetPageRoute(
        page: () => HomeModulePage(),
        binding: HomeModuleBinding(),
        transition: Transition.fadeIn,
      ),
  Routes.HOME: () => GetPageRoute(
        page: () => HomeModulePage(),
        binding: HomeModuleBinding(),
        transition: Transition.fadeIn,
      ),
  Routes.LETTER_RECEIVING_DETAIL: () => GetPageRoute(
        page: () =>  LetterReceivingDetailModulePage(),
        binding: LetterReceivingDetailModuleBinding(),
        transition: Transition.fadeIn,
      ),
  Routes.PENPAL: () => GetPageRoute(
        page: () => PenpalModulePage(),
        binding: PenpalModuleBinding(),
        transition: Transition.fadeIn,
      ),
  Routes.STAMPS: () => GetPageRoute(
        page: () => const StampsModulePage(),
        binding: StampsModuleBinding(),
        transition: Transition.fadeIn,
      ),
  Routes.USERINFO: () => GetPageRoute(
        page: () => UserInfoModulePage(),
        binding: UserInfoModuleBinding(),
        transition: Transition.fadeIn,
      ),
  Routes.SETTINGS: () => GetPageRoute(
        page: () => SettingsModulePage(),
        binding: SettingsModuleBinding(),
      ),
  Routes.NOTIFICATION_MANAGER: () => GetPageRoute(
        page: () => NotificationManagerModulePage(),
        binding: NotificationManagerModuleBinding(),
      ),
  Routes.STAMPS_STORE: () => GetPageRoute(
        page: () => StampsStoreModulePage(),
        binding: StampsStoreModuleBinding(),
      ),
  Routes.MARKS: () => GetPageRoute(
        page: () => MarksModulePage(),
        binding: MarksModuleBinding(),
      )
};

class FFPOPage extends GetView<FFPOController> {
  final _ = Get.find<FFPOController>();

  @override
  Widget build(BuildContext context) {
    return ZoomDrawer(
        controller: _.zoomDrawerController,
        menuScreen: const MenuModulePage(),
        mainScreen: content(),
        borderRadius: 50.0,
        angle: 0,
        menuBackgroundColor: navyBlue,
        menuScreenOverlayColor: Colors.black,
        slideWidth: MediaQuery.of(context).size.width * 0.65);
  }

  Widget content() {
    return Navigator(
        key: Get.nestedKey(1), // create a key by index
        initialRoute: "/",
        onGenerateRoute: (settings) {
          return routes[settings.name]();
        });
  }
}
