import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/modules/menu_module/logic.dart';
import 'package:get/get.dart';
/**
 * GetX Template Generator - fb.com/htngu.99
 * */

class FFPOBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FFPOController());
    Get.lazyPut(()=>MenuModuleLogic());
  }
}