import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/data/model/stamp_detail.dart';
import 'package:ffpo_app/app/data/model/user.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_zoom_drawer/config.dart';
import 'package:get/get.dart';
/**
 * GetX Template Generator - fb.com/htngu.99
 * */

class FFPOController extends GetxController {
  static double safeAreaHeight = 1.sh - ScreenUtil().statusBarHeight - ScreenUtil().bottomBarHeight;
  var _obj = ''.obs;

  set obj(value) => _obj.value = value;

  get obj => _obj.value;
  final zoomDrawerController = ZoomDrawerController();

  void toggleDrawer() {
    zoomDrawerController.toggle?.call();
    update();
  }

  List<Mail> mails = [];
  late User user;
  List<StampDetail> stampDetails = [];
}
