import '../../data/model/mail.dart';

class SearchModuleState {
  late List<Mail> result;
  SearchModuleState() {
    ///Initialize variables

  }
}
