import 'package:get/get.dart';

import 'logic.dart';

class SearchModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SearchModuleLogic());
  }
}
