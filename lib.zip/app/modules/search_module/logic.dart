import 'package:get/get.dart';

import 'state.dart';

class SearchModuleLogic extends GetxController {
  final SearchModuleState state = SearchModuleState();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    state.result = Get.arguments;

  }
}
