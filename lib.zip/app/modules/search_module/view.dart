import 'package:ffpo_app/app/global_widgets/page_head.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/modules/home_module/local_widgets/date_classified_box.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../theme/app_colors.dart';
import '../home_module/local_widgets/letter_box.dart';
import 'logic.dart';

class SearchModulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<SearchModuleLogic>();
    final state = Get.find<SearchModuleLogic>().state;
    List<Widget> list = [SizedBox(height: 27.h)];
    for (int i = 0; i < state.result.length; i++) {
      list.add(HomeLetterBoxComponent(mail: state.result[i]));
      list.add(SizedBox(height: 50.h));
    }
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
              left: 20.w,
              top: 21.h,
              child: Container(
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
                  width: 250.w,
                  child: Row(children: [
                    GestureDetector(
                        onTap: () =>  Get.offNamedUntil(Routes.FFPO, (route) => false),
                        child: Container(
                            width: 40.h,
                            height: 40.h,
                            decoration: const BoxDecoration(color: navyBlue, shape: BoxShape.circle),
                            child: Icon(Icons.arrow_back_ios_outlined, color: Colors.white, size: 33.h))),
                    SizedBox(width: 20.w),
                    Text("搜索结果", style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1, fontSize: 33.sp))
                  ]))),
          Positioned(
              top: 70.h,
              child: Container(
                  width: 1.sw,
                  height: FFPOController.safeAreaHeight,
                  child: SingleChildScrollView(child: Column(children: list))))
        ],
      ),
    );
  }
}
