import 'package:get/get.dart';

import 'state.dart';

class MineModuleLogic extends GetxController {
  final MineModuleState state = MineModuleState();
}
