import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class MineModulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<MineModuleLogic>();
    final state = Get.find<MineModuleLogic>().state;

    return Container();
  }
}
