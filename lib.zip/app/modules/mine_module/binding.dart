import 'package:get/get.dart';

import 'logic.dart';

class MineModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => MineModuleLogic());
  }
}
