class MineModuleState {
  MineModuleState() {
    ///Initialize variables
  }
}
