class NotificationManagerModuleState {
  NotificationManagerModuleState() {
    ///Initialize variables
  }
}
