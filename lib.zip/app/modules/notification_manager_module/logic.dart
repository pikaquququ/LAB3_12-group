import 'package:get/get.dart';

import 'state.dart';

class NotificationManagerModuleLogic extends GetxController {
  final NotificationManagerModuleState state = NotificationManagerModuleState();
}
