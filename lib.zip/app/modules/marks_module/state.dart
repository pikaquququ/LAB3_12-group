class MarksModuleState {
  MarksModuleState() {
    ///Initialize variables
  }
}
