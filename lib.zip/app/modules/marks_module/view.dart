import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../global_widgets/page_head.dart';
import 'logic.dart';

class MarksModulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<MarksModuleLogic>();
    final state = Get.find<MarksModuleLogic>().state;

    return Scaffold(
      body: Stack(
        children: [
          Positioned(left: 20.w, top: 21.h, child: const PageHead(title: "我的收藏", type: "primary")),
        ],
      ),
    );
  }
}
