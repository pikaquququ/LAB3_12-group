import 'package:get/get.dart';

import 'state.dart';

class MarksModuleLogic extends GetxController {
  final MarksModuleState state = MarksModuleState();
}
