import 'package:get/get.dart';

import 'logic.dart';

class StampCollectionModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => StampCollectionModuleLogic());
  }
}
