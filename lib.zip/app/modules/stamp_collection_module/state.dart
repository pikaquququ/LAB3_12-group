class StampCollectionModuleState {
  StampCollectionModuleState() {
    ///Initialize variables
  }
}
