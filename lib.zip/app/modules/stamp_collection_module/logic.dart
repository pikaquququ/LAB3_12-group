import 'package:get/get.dart';

import 'state.dart';

class StampCollectionModuleLogic extends GetxController {
  final StampCollectionModuleState state = StampCollectionModuleState();
}
