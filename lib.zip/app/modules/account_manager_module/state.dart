class AccountManagerModuleState {
  AccountManagerModuleState() {
    ///Initialize variables
  }
}
