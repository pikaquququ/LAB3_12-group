import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class AccountManagerModulePage extends StatelessWidget {
  const AccountManagerModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<AccountManagerModuleLogic>();
    final state = Get.find<AccountManagerModuleLogic>().state;

    return Container();
  }
}
