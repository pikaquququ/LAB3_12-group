import 'package:ffpo_app/app/modules/menu_module/logic.dart';
import 'package:ffpo_app/app/modules/penpal_module/logic.dart';
import 'package:get/get.dart';

import 'logic.dart';

class HomeModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => HomeModuleLogic());
    Get.lazyPut(() => MenuModuleLogic());
    Get.lazyPut(() => PenpalModuleLogic());

  }
}
