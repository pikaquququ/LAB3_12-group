import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/data/provider/api_provider.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/modules/home_module/local_widgets/search.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter_zoom_drawer/config.dart';
import 'package:get/get.dart';
import 'state.dart';

class HomeModuleLogic extends GetxController {
  final HomeModuleState state = HomeModuleState();
  final zoomDrawerController = ZoomDrawerController();
  static int count = 0;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    final appCtl = Get.find<FFPOController>();
    appCtl.mails.sort((a, b) => a.sendTime.isBefore(b.sendTime) ? 1 : 0);

    for (var mail in appCtl.mails) {
      int flag = 0;
      for (var mails in state.mailSortByDate) {
        if (mails[0].sendTime.day == mail.sendTime.day) {
          mails.add(mail);
          flag = 1;
          break;
        }
      }
      if (flag == 0) {
        List<Mail> mails = [mail];
        state.mailSortByDate.add(mails);
      }
    }
  }



  void toSearch(){
    Get.dialog(Search());
  }


  void search(String tag)async{
    List<Mail> result = [];
    List<Mail > temp = await ApiProvider.elSearch(tag);
    final ctl = Get.find<FFPOController>();
    temp.forEach((element) {
      for (var m in ctl.mails) {
        if(element.id==m.id){
          result.add(m);
          break;
        }
      }
    });

    if(result.isEmpty)return;
    else{
      Get.toNamed(Routes.SEARCH,arguments: result);
    }
  }
}
