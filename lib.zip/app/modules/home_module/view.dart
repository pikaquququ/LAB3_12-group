import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/modules/home_module/local_widgets/date_classified_box.dart';
import 'package:ffpo_app/app/modules/home_module/local_widgets/search_box.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'logic.dart';

class HomeModulePage extends StatelessWidget {
  const HomeModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<HomeModuleLogic>();
    final state = Get.find<HomeModuleLogic>().state;
    final appCtl = Get.find<FFPOController>();
    return Scaffold(
      resizeToAvoidBottomInset: false,
        body: Stack(children: [
      Positioned(
          top: 0,
          child: Container(
              width: 1.sw,
              height: FFPOController.safeAreaHeight,
              child: SingleChildScrollView(
                  child: Column(children: [
                SizedBox(height: 77.h),
                for (int i = 0; i < state.mailSortByDate.length; i++)
                  HomeDateClassifiedBoxComponent(periodicMails: state.mailSortByDate[i])
              ])))),
      Positioned(
          right: 30.h,
          bottom: 60.h,
          child: GestureDetector(
              onTap: () => Get.toNamed(Routes.LETTER_WRITE_CONTENT),
              child: Container(
                  width: 80.h,
                  height: 80.h,
                  decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                          begin: Alignment.bottomRight,
                          end: Alignment.topLeft,
                          colors: [Color(0xff59999c), Colors.white],
                          stops: [0.7, 1])),
                  child: Icon(Icons.add_rounded, color: Colors.white, size: 80.h)))),
      /// 用户头像
      Positioned(
          left: 18.w,
          top: 17.h,
          child: GestureDetector(
              onTap: () => appCtl.toggleDrawer(),
              child: ClipOval(child: Image.network(appCtl.user.headImg ?? "", width: 60.h, height: 60.h,)))),
      Positioned(
          right: 22.w,
          top: 27.h,
          child:SearchBox()),
    ]));
  }
}
