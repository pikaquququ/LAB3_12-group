import 'dart:ffi';

import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SearchBox extends StatefulWidget {
  const SearchBox({Key? key}) : super(key: key);

  @override
  State<SearchBox> createState() => _SearchBoxState();
}

class _SearchBoxState extends State<SearchBox> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation width;
  late bool searching;

  @override
  void initState() {
    searching = false;
    _animationController = AnimationController(vsync: this, duration: Duration(milliseconds: 300))
      ..addListener(() {
        setState(() {});
      });
    width = TweenSequence([TweenSequenceItem(tween: Tween(begin: 50.h, end: 180.w), weight: 1)])
        .animate(CurvedAnimation(parent: _animationController, curve: Curves.easeInOut));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: width.value,
        height: 50.h,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(25.h), color: const Color(0xffADCFC8)),
        child: Stack(
          children: [
            Positioned(
                right: 0,
                child: GestureDetector(
                    onTap: () {
                      if (searching) {
                        _animationController.reverse();
                      } else {
                        _animationController.forward();
                      }
                      searching = !searching;
                    },
                    child: ClipOval(
                        child:
                            Container(width: 50.h, height: 50.h, color: navyBlue, child: const Icon(Icons.search))))),
            Positioned(
                left: 0,
                child: searching
                    ? Container(
                        width: 180.w - 50.h,
                        height: 50.h,
                        child: TextField(
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.sp
                          ),
                          decoration: InputDecoration(border: InputBorder.none),
                        ))
                    : Container())
          ],
        ));
  }
}
