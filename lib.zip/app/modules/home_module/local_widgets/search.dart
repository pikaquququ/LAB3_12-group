import 'package:ffpo_app/app/data/provider/api_provider.dart';
import 'package:ffpo_app/app/modules/home_module/logic.dart';
import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class Search extends StatelessWidget {
  Search({Key? key}) : super(key: key);

  final TextEditingController _textEditingController = TextEditingController();
final ctl = Get.find<HomeModuleLogic>();
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Material(
            borderRadius: BorderRadius.circular(30.h),
            child: Container(
                width: 0.6.sw,
                height: 60.h,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30.h)),
                child: TextField(
                    controller: _textEditingController,
                    textAlign: TextAlign.center,
                    cursorColor: navyBlue,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30.sp),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        suffixIcon: GestureDetector(
                            onTap: () =>ctl.search(_textEditingController.text),
                            child: Icon(Icons.search, color: Colors.black)))))));
  }
}
