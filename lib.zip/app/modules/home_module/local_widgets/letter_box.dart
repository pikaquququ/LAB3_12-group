import 'package:ffpo_app/app/modules/home_module/state.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../data/model/mail.dart';

class HomeLetterBoxComponent extends StatelessWidget {
  static int index = 0;
  static final colorMap = {
    0: const Color(0xff87C0CA),
    1: const Color(0xff92C5C6),
    2: const Color(0xff8BB7A2),
    3: const Color(0xff509296)
  };

  const HomeLetterBoxComponent({Key? key, required this.mail}) : super(key: key);
  final Mail mail;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.toNamed(Routes.LETTER_RECEIVING_DETAIL, arguments: mail),
      child: Container(
          width: 350.w,
          height: 150.h,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40.h),
              color: colorMap[(index++) % 4],
              boxShadow: const [BoxShadow(color: Colors.grey, offset: Offset(0, 3), blurRadius: 3)]),
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Row(children: [
            SizedBox(width: 20.w,),
            Container(
              width: 200.w,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("From ${mail.sendUserName ?? '空'}", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.sp,letterSpacing: 2)),
                    Text("《${mail.title??""}》", style: TextStyle(fontSize: 18.sp))
                  ]),
            ),
            Container(
              width: 90.w,
              height: 120.h,
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20.h)),
              child: Center(
                child: Container(
                  width: 100.w,
                  height: 140.h,
                  constraints: BoxConstraints(minHeight: 1000.h,minWidth:100.w, ),
                  child: Image.network(mail.stampImg ?? "",
                      // width: 100.w,
                      // height: 140.h,
                      // fit:BoxFit.cover,
                      errorBuilder: (context, _1, _2) => Image.asset("assets/images/default.png", fit:BoxFit.cover,width: 100.w, height: 140.h)),
                ),
              ),
            )
          ])),
    );
  }
}
