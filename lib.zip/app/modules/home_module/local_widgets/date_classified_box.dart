import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/modules/home_module/local_widgets/letter_box.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeDateClassifiedBoxComponent extends StatelessWidget {
  const HomeDateClassifiedBoxComponent({Key? key, required this.periodicMails}) : super(key: key);

  final List<Mail> periodicMails;

  @override
  Widget build(BuildContext context) {
    List<Widget> content = [];
    DateTime time = periodicMails[0].sendTime;
    content.add(Align(
        alignment: Alignment(-0.8, 0),
        child: Text(
          "Date: ${time.year}.${time.month}.${time.day}",
          style:TextStyle(fontSize: 25.sp),
        )));
    content.add(Divider(
      indent: 0.12.sw,
      endIndent: 0.60.sw,
      thickness: 1,
      color: Colors.black,
      height: 30.h,
    ));
    periodicMails.forEach((element) {
      content.add(HomeLetterBoxComponent(mail: element));
      content.add(SizedBox(height: 20.h));
    });

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: content,
    );
  }
}
