import '../../data/model/mail.dart';

class HomeModuleState {
  late List<List<Mail>> mailSortByDate;


  HomeModuleState() {
    ///Initialize variables
    mailSortByDate = [];
  }
}
