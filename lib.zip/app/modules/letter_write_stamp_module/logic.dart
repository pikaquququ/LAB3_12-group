import 'package:easy_dialog/easy_dialog.dart';
import 'package:ffpo_app/app/data/model/mail_draft.dart';
import 'package:ffpo_app/app/data/model/stamp_detail.dart';
import 'package:ffpo_app/app/data/provider/api_provider.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'state.dart';

class LetterWriteStampModuleLogic extends GetxController {
  final LetterWriteStampModuleState state = LetterWriteStampModuleState();

  List<List<StampDetail>> stampSortByType = [];

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    final appCtl = Get.find<FFPOController>();
    // print(appCtl.stampDetails);
    appCtl.stampDetails.forEach((stampDetail) {
      int flag = 0;
      for (var stampDetails in stampSortByType) {
        if (stampDetails[0].type == stampDetail.type) {
          stampDetails.add(stampDetail);
          flag = 1;
          break;
        }
      }
      if (flag == 0) {
        stampSortByType.add([stampDetail]);
      }
    });
    state.curStampUrl = "";
    state.mailDraft = Get.arguments;

  }


  void changeView(String label){
    state.classifyStr=label;
    update(["stamps"]);
  }

  void changeExhibition(StampDetail stampDetail){
    state.curStampUrl=stampDetail.img??"";
    state.mailDraft.stampId=stampDetail.id;
    update(["exhibition"]);
  }

  void send()async{
    BuildContext? context = Get.context;
    EasyLoading.show(status: 'loading...');
    await Future.delayed(Duration(seconds: 2));
    EasyLoading.dismiss();
    // String? sendTime = await ApiProvider.sendMail(state.mailDraft);
    EasyDialog(
        title: Text("发送成功",style: TextStyle(fontSize: 30.sp,fontWeight: FontWeight.bold),),
        description: Text("预计2022年11月23日送达")).show(context!);
    // if(sendTime==null)return;
    // else{
    //   print(sendTime);
    // }
  }
}
