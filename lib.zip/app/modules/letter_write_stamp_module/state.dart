import '../../data/model/mail_draft.dart';

class LetterWriteStampModuleState {
  late String classifyStr;
  late String curStampUrl;
   late MailDraft mailDraft;
  LetterWriteStampModuleState() {
    ///Initialize variables
    classifyStr="动物";

  }
}
