import 'package:ffpo_app/app/data/model/stamp_detail.dart';
import 'package:ffpo_app/app/global_widgets/page_head.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/modules/letter_write_stamp_module/local_widgets/classify_box.dart';
import 'package:ffpo_app/app/modules/letter_write_stamp_module/local_widgets/classify_view.dart';
import 'package:ffpo_app/app/modules/letter_write_stamp_module/local_widgets/stamp_exhibition.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../theme/app_colors.dart';
import 'logic.dart';

class LetterWriteStampModulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<LetterWriteStampModuleLogic>();
    final state = Get.find<LetterWriteStampModuleLogic>().state;
    final ctl = Get.find<FFPOController>();
    print(ctl.stampDetails);
    return Scaffold(
        body: SafeArea(
            child: Stack(alignment: Alignment.center, children: [
      Positioned(left: 20.w, top: 21.h, child: const PageHead(title: "邮票选择", type: "secondary")),
      Positioned(top: 117.h, child: StampExhibition()),
      Positioned(
          top: 546.h,
          child: Container(
              width: 1.sw,
              height: 1.sh - 546.h,
              decoration: BoxDecoration(color: navyBlue, borderRadius: BorderRadius.circular(40.h)))),
      Positioned(top: 546.h + 80.h, child: const ClassifyView()),
      Positioned(
          top: 546.h,
          child: Container(
              width: 1.sw,
              height: 80.h,
              decoration: BoxDecoration(color: navyBlue, borderRadius: BorderRadius.circular(40.h), boxShadow: [
                BoxShadow(offset: const Offset(0, 2), blurRadius: 10, color: Colors.black.withOpacity(0.4))
              ]),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: const [
                ClassifyBox(label: "动物"),
                ClassifyBox(label: "建筑"),
                ClassifyBox(label: "花卉"),
                ClassifyBox(label: "节日"),
                ClassifyBox(label: "自定义")
              ]))),
      Positioned(
          bottom: 25.h,
          child: GestureDetector(
            onTap: ()=>logic.send(),
            child: Container(
                width: 150.w,
                height: 60.h,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30.h),
                    color: Colors.white,
                    boxShadow: const [BoxShadow(color: Colors.grey, offset: Offset(0, 3), blurRadius: 3)]),
                child: Center(child: Text("完成"))),
          ))
    ])));
  }
}
