import 'package:ffpo_app/app/data/model/stamp_detail.dart';
import 'package:ffpo_app/app/modules/letter_write_stamp_module/logic.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../theme/app_colors.dart';

class ClassifyView extends StatelessWidget {
  const ClassifyView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<LetterWriteStampModuleLogic>(
        id: "stamps",
        builder: (ctl) {
          List<StampDetail> stampDetails = [];
          for (var element in ctl.stampSortByType) {
            if (ctl.state.classifyStr == element[0].type) {
              stampDetails = element;
              break;
            }
          }
          return Container(
              width: 1.sw,
              height: 1.sh - 546.h - 80.h,
              decoration: BoxDecoration(color: navyBlue, borderRadius: BorderRadius.circular(40.h)),
              child: GridView.count(
                  childAspectRatio: 0.75,
                  crossAxisCount: 3,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                  children: [
                    for (StampDetail e in stampDetails)
                      GestureDetector(
                        onTap: () => ctl.changeExhibition(e),
                        child: FadeInImage.assetNetwork(
                          placeholder: "assets/images/loading.gif",
                          image: e.img ?? "",
                          fit: BoxFit.cover,
                          fadeOutDuration: Duration(seconds: 1),
                          // fadeInDuration: const Duration(seconds: 1),
                          imageErrorBuilder: ( context, obj, stackTrace)=> Image.asset("assets/images/default.png", fit: BoxFit.fill),
                        ),
                        // Image.network(
                        //   e.img ?? "",
                        //   fit: BoxFit.fill,
                        //   errorBuilder: (context, _1, _2) => Image.asset("assets/images/default.png", fit: BoxFit.fill),
                        //   loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                        //
                        //     return Container(color: Colors.grey,child: child);
                        //   },
                        // ),
                      )
                  ]));
        });
  }
}
