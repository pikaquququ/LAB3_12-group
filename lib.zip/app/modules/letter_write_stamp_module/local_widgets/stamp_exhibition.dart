import 'package:ffpo_app/app/modules/letter_write_stamp_module/logic.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class StampExhibition extends StatelessWidget {
  const StampExhibition({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return GetBuilder<LetterWriteStampModuleLogic>(
      id: "exhibition",
      builder: (ctl) {
        print("rebuild");
        return Image.network(ctl.state.curStampUrl,
            width: 240.w,
            height: 340.h,
            errorBuilder: (context, _, _1) => Image.asset("assets/images/default.png", width: 240.w, height: 340.h));
      }
    );
  }
}
