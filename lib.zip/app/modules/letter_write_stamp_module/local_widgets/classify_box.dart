import 'package:ffpo_app/app/modules/letter_write_stamp_module/logic.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class ClassifyBox extends StatelessWidget {
  const ClassifyBox({Key? key, required this.label}) : super(key: key);
  final String label;

  @override
  Widget build(BuildContext context) {
    final ctl = Get.find<LetterWriteStampModuleLogic>();

    return GestureDetector(
        onTap: () => ctl.changeView(label),
        child: Container(
            width: 60.h,
            height: 60.h,
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: Center(child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold)))));
  }
}
