import 'package:ffpo_app/app/global_widgets/mtable.dart';
import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../global_widgets/page_head.dart';
import 'logic.dart';

class PenpalModulePage extends StatefulWidget {
  const PenpalModulePage({Key? key}) : super(key: key);

  @override
  State<PenpalModulePage> createState() => _PenpalModulePageState();
}

class _PenpalModulePageState extends State<PenpalModulePage> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final tabs = ["我的好友", "同学", "家人", "陌生人"];
    return Scaffold(
      body: Stack(children: [
        Positioned(left: 20.w, top: 21.h, child: const PageHead(title: "我的笔友", type: "primary")),
        Positioned(
            top: 102.h,
            child: SizedBox(
                width: 1.sw,
                height: 1.sh - 102.h,
                child: Scaffold(
                    appBar: AppBar(
                        backgroundColor: navyBlue,
                        title: TabBar(
                            overlayColor: MaterialStateProperty.all(navyBlue),
                            unselectedLabelColor: Colors.white,
                            indicator: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(40.h)),
                            controller: _tabController,
                            labelColor: Colors.black,
                            labelPadding: EdgeInsets.zero,
                            labelStyle: TextStyle(color: Colors.black, fontSize: 20.sp, fontWeight: FontWeight.bold),
                            tabs: tabs.map((e) => Tab(text: e)).toList())),
                    body: TabBarView(controller: _tabController, children: [
                      Stack(alignment: Alignment.center, children: [
                        Positioned(
                            top: 20.h,
                            child: Container(
                                child: MTable(widgets: [
                              Row(
                                children: [Text("胡萝卜"), Icon(Icons.chat)],
                              ),
                              Row(
                                children: [Text("胡萝卜"), Icon(Icons.chat)],
                              ),
                              Row(
                                children: [Text("胡萝卜"), Icon(Icons.chat)],
                              ),
                              Row(
                                children: [Text("胡萝卜"), Icon(Icons.chat)],
                              )
                            ])))
                      ]),
                      Container(),
                      Container(),
                      Container(),
                    ]))))
      ]),
    );
  }
}
