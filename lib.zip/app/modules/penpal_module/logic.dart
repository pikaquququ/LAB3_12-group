import 'package:get/get.dart';

import 'state.dart';

class PenpalModuleLogic extends GetxController {
  final PenpalModuleState state = PenpalModuleState();
}
