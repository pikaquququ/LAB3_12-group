import 'package:get/get.dart';

import 'logic.dart';

class PenpalModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => PenpalModuleLogic());
  }
}
