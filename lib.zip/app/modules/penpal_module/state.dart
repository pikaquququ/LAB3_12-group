class PenpalModuleState {
  PenpalModuleState() {
    ///Initialize variables
  }
}
