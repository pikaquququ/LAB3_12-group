import 'package:flutter/cupertino.dart';

class LetterReceivingDetailModuleState {
  late TextEditingController content;
  LetterReceivingDetailModuleState() {
    ///Initialize variables
    content  =TextEditingController();
  }
}
