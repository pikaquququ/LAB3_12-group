import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class LetterReceivingDetailOptionsComponent extends StatelessWidget {
  const LetterReceivingDetailOptionsComponent({Key? key, required this.mail}) : super(key: key);

  final Mail mail;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: 0.6.sw,
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          Column(children: [
            ClipOval(
                child: Container(
                    width: 60.h,
                    height: 60.h,
                    color: const Color.fromRGBO(173, 207, 200, 0.8),
                    child: Center(child: Image.asset("assets/icons/share.png", color: Colors.white)))),
            const Text("分享")
          ]),
          Column(children: [
            ClipOval(
                child: Container(
                    width: 60.h,
                    height: 60.h,
                    color: const Color.fromRGBO(173, 207, 200, 0.8),
                    child: Center(
                        child: Image.asset("assets/icons/save.png", width: 30.h, height: 30.h, color: Colors.white)))),
            const Text("保存")
          ]),
          Column(children: [
            ClipOval(
                child: GestureDetector(
              onTap: () => Get.toNamed(Routes.LETTER_WRITE_CONTENT, arguments: {
                "sendUserName": mail.sendUserName,
              }),
              child: Container(
                  width: 60.h,
                  height: 60.h,
                  color: const Color.fromRGBO(173, 207, 200, 0.8),
                  child: Center(
                      child: Image.asset("assets/icons/mail.png", width: 40.h, height: 40.h, color: Colors.white))),
            )),
            const Text("回信")
          ])
        ]));
  }
}
