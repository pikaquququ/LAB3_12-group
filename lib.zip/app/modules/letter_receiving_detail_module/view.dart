import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/global_widgets/page_head.dart';
import 'package:ffpo_app/app/global_widgets/text_editor.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'local_widgets/options.dart';
import 'logic.dart';

class LetterReceivingDetailModulePage extends StatelessWidget {
  LetterReceivingDetailModulePage({Key? key}) : super(key: key);

  // final Mail mail;
  final Mail mail = Get.arguments;

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<LetterReceivingDetailModuleLogic>();
    final state = Get.find<LetterReceivingDetailModuleLogic>().state;
    state.content.text = mail.msg ?? "内容为空";
    return SafeArea(
        child: Scaffold(
            body: Stack(alignment: Alignment.center, children: [
      Positioned(
          left: 20.w,
          top: 21.h,
          child: PageHead(
            title: "信件详情",
            type: "secondary",
          )),
      Positioned(
          top: 121.h,
          child: TextEditor(
              maxLine: 11,
              controller: state.content,
              fontSize: 21.sp,
              width: 350.w,
              height: 690.w,
              enabled: false,
              borderRadius: BorderRadius.circular(30.h))),
      Positioned(
          left: 10.w,
          top: 680.h,
          child: Transform(
            child: Image.asset("assets/images/stamp1.png",fit: BoxFit.cover, width: 120.w, height: 180.h),
            transform: Matrix4.rotationZ(-0.5),
          )),
      Positioned(
          right: 0,
          top: 570.h,
          child: Image.asset("assets/images/flower.png", width: 280.w, height: 280.h,fit: BoxFit.cover)),
      Positioned(left: 0.3.sw, bottom: 0.h, child:  LetterReceivingDetailOptionsComponent(mail: mail))
    ])));
  }
}
