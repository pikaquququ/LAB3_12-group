import 'package:get/get.dart';

import 'state.dart';

class LetterReceivingDetailModuleLogic extends GetxController {
  final LetterReceivingDetailModuleState state = LetterReceivingDetailModuleState();
}
