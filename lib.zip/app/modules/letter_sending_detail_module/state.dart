class LetterSendingDetailModuleState {
  LetterSendingDetailModuleState() {
    ///Initialize variables
  }
}
