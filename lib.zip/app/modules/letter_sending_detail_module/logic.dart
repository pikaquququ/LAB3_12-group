import 'package:get/get.dart';

import 'state.dart';

class LetterSendingDetailModuleLogic extends GetxController {
  final LetterSendingDetailModuleState state = LetterSendingDetailModuleState();
}
