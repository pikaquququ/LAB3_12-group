import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class LetterSendingDetailModulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<LetterSendingDetailModuleLogic>();
    final state = Get.find<LetterSendingDetailModuleLogic>().state;

    return Container();
  }
}
