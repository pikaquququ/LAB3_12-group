import 'package:flutter/cupertino.dart';

class RegisterModuleState {
 late  TextEditingController userName;
 late  TextEditingController password;
 late  TextEditingController passwordRepeat;
 late  TextEditingController phone;
 late  TextEditingController authCode;

  RegisterModuleState() {
    ///Initialize variables
    userName=TextEditingController();
    password=TextEditingController();
    passwordRepeat=TextEditingController();
    phone=TextEditingController();
    authCode=TextEditingController();
  }
}
