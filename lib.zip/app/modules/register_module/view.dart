import 'dart:ui';

import 'package:ffpo_app/app/modules/register_module/local_widgets/register_form.dart';
import 'package:ffpo_app/app/modules/start_module/local_widgets/start_mask.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'logic.dart';

class RegisterModulePage extends StatelessWidget {
  const RegisterModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<RegisterModuleLogic>();
    final state = Get.find<RegisterModuleLogic>().state;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(alignment: Alignment.center, children: [
        Positioned(
            child: ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 6, sigmaY: 10), child: Image.asset("assets/images/bg.png"))),
        const Positioned(child: StartMask()),
        Positioned(
            top: 86.h,
            child: Container(
              width: 170.h,
              height: 170.h,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Color(0xffA2A2A2)),
            )),
        // 542-469 73
        Positioned(top: 393.h - 73.h, child: RegisterFormComponent()),
        Positioned(
            top: 778.h,
            left: 134.w,
            child: Container(
                width: 160.w,
                height: 60.h,
                decoration: BoxDecoration(
                  boxShadow: const [BoxShadow(color: Colors.grey, offset: Offset(0, 4), blurRadius: 2)],
                  borderRadius: BorderRadius.circular(30.h),
                  gradient: const LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: [Color(0xff68abbb), Color(0xff91c2c6)],
                      stops: [0.8, 1]),
                ),
                child: Center(
                    child: Text("完成",
                        style: TextStyle(
                            fontWeight: FontWeight.w400, fontSize: 32.sp, letterSpacing: 1, color: Colors.white))))),
        Positioned(
            left: 10.w,
            top: 10.h,
            child: GestureDetector(
              onTap: () => Get.back(),
              child: Container(
                width: 40.h,
                height: 40.h,
                decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                child: const Icon(Icons.arrow_back_ios_outlined),
              ),
            ))
      ]),
    );
  }
}
