import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class RegisterFormItemComponent extends StatelessWidget {
  RegisterFormItemComponent({Key? key, required this.label, required this.controller, this.suffix}) : super(key: key);

  String label;
  Widget? suffix;
  TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 73.h,
        width: 329.w,
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(width: 2,color: Colors.white))),
        child: TextField(
            decoration: InputDecoration(
                labelText: label,
                hintStyle: const TextStyle(color: Colors.white),
                border: InputBorder.none,
                labelStyle:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.w400, fontSize: 24.sp, letterSpacing: 4),
                suffixIcon: suffix)));
  }
}
