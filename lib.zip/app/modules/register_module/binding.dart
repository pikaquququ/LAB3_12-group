import 'package:get/get.dart';

import 'logic.dart';

class RegisterModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RegisterModuleLogic());
  }
}
