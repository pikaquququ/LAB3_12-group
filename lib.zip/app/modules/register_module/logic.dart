import 'package:get/get.dart';

import 'state.dart';

class RegisterModuleLogic extends GetxController {
  final RegisterModuleState state = RegisterModuleState();
}
