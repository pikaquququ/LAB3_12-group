import 'package:ffpo_app/app/modules/menu_module/logic.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class MenuItem extends StatelessWidget {
  const MenuItem({Key? key, required this.label, required this.route,required this.index
  }) : super(key: key);
  final String label;
  final String route;
final int index;
  @override
  Widget build(BuildContext context) {
final ctl  =Get.find<MenuModuleLogic>();
    return GestureDetector(
      onTap: () =>ctl.change(route, index),
      child: Container(
          width: 136.w,
          height: 80.h,
          child: Center(
              child: Text(
                label,
                style: TextStyle(fontWeight: FontWeight.w500, fontSize: 22.sp),
              ))),
    );
  }
}
