import 'package:ffpo_app/app/modules/menu_module/local_widgets/menu_item.dart';
import 'package:ffpo_app/app/modules/menu_module/logic.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class MenuItemList extends StatelessWidget {
  const MenuItemList({Key? key}) : super(key: key);

 static final List items = [
    {"id": 1, "label": "我的笔友", "route": Routes.PENPAL, "icon": ""},
    {"id": 2, "label": "我的邮票", "route": Routes.STAMPS, "icon": ""},
    {"id": 3, "label": "我的收藏", "route": Routes.MARKS, "icon": ""},
    {"id": 4, "label": "邮票商店", "route": Routes.STAMPS_STORE, "icon": ""},
    {"id": 5, "label": "通知管理", "route": Routes.NOTIFICATION_MANAGER, "icon": ""},
  ];

  @override
  Widget build(BuildContext context) {

    return GetBuilder<MenuModuleLogic>(
        id: "menu_list",
        builder: (ctl) {
          return SizedBox(
              height: (items.length+1)*80.h,
              width: 0.5.sw,
              child: Stack(children: [
                Positioned(
                    top: ctl.state.index * 80.h + 10.h,
                    child: Container(
                      width: 0.5.sw,
                      height: 60.h,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.only(bottomRight: Radius.circular(30.h), topRight: Radius.circular(30.h))),
                    )),
                Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  const Align(alignment: Alignment(-0.5, 0), child: MenuItem(label: "首页", route: Routes.HOME, index: 0)),
                  for (int i = 0; i < items.length; i++)
                    MenuItem(label: items[i]["label"], route: items[i]["route"], index: items[i]["id"])
                ]),
              ]));
        });
  }
}
