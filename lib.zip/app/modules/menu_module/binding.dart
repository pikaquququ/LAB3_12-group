import 'package:get/get.dart';

import 'logic.dart';

class MenuModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => MenuModuleLogic());
  }
}
