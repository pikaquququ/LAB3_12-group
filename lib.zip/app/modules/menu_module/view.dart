import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/modules/menu_module/local_widgets/menu_item_list.dart';
import 'package:ffpo_app/app/modules/menu_module/logic.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class MenuModulePage extends StatelessWidget {
  const MenuModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ctl = Get.find<MenuModuleLogic>();
    final appCtl = Get.find<FFPOController>();
    return Container(
        height: 1.sh,
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xffADCFC8), Color.fromRGBO(225, 193, 195, 0)],
                stops: [0, 0.1])),
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          GestureDetector(
              onTap: () => Get.toNamed(Routes.LETTER_RECEIVING_DETAIL, id: 1),
              child: Container(
                width: 120.h,
                height: 120.h,
                decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                child: ClipOval(child: Image.network(appCtl.user.headImg ?? "")),
              )),
          const MenuItemList(),
          GestureDetector(
            onTap: () => ctl.change(Routes.SETTINGS, ctl.state.index),
            child: SizedBox(
                width: 0.5.sw,
                child: Align(
                    alignment: const Alignment(-0.6, 0),
                    child: Column(children: [
                      Container(
                          width: 60.h,
                          height: 60.h,
                          decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xff509296)),
                          child: Icon(Icons.settings, color: Colors.white, size: 40.h)),
                      const Text("设置")
                    ]))),
          )
        ]));
  }
}
