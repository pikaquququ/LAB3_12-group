class MenuModuleState {

  late int index;
  MenuModuleState() {
    ///Initialize variables
    index =0;
  }
}
