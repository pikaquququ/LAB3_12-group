import 'package:get/get.dart';

import 'state.dart';

class MenuModuleLogic extends GetxController {
  final MenuModuleState state = MenuModuleState();
  void change(String route,int index){
    Future.delayed(Duration(seconds: 0),()=>    Get.offAndToNamed(route,id: 1));

    state.index=index;
    update(["menu_list"]);
  }
}
