class StampsModuleState {
  StampsModuleState() {
    ///Initialize variables
  }
}
