import 'package:ffpo_app/app/global_widgets/page_head.dart';
import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class StampsModulePage extends StatelessWidget {
  const StampsModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(alignment: Alignment.center, children: [
      Positioned(child: Image.asset("assets/images/stamp_bg.png", width: 1.sw, height: 1.sh, fit: BoxFit.fill)),
      Positioned(left: 20.w, top: 21.h, child: const PageHead(title: "邮票图鉴", type: "primary")),
      Positioned(
          left: -20.w,
          child: Container(
              width: 428.w,
              height: 582.h,
              decoration: const BoxDecoration(color: navyBlue),
              child: Stack(alignment: Alignment.center, children: [
                for (int i = 1; i <= 3; i++)
                  Positioned(
                      left: 48.w + i * 5.w,
                      child: Container(width: 352.w, height: 500.h - i * 10.h, color: Colors.white.withOpacity(0.4))),
                Positioned(
                    left: 48.w,
                    child:
                        Container(width: 352.w, height: 500.h, decoration: const BoxDecoration(color: Colors.white))),
              ]))),
      Positioned(
          left: 0,
          child: Container(
            height: 500.h,
            width: 15.w,
            color: Colors.white,
          )),
      for (int i = 0; i < 6; i++)
        Positioned(
            left: 0,
            top: 253.h + i * 51.h + i ~/ 2 * 48.h,
            child: Image.asset("assets/images/clip.png", width: 60.w, height: 34.h, fit: BoxFit.fill)),
    ]));
  }
}
