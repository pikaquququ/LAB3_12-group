import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class LoginModulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<LoginModuleLogic>();
    final state = Get.find<LoginModuleLogic>().state;

    return Container();
  }
}
