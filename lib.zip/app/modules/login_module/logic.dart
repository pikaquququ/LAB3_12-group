import 'package:get/get.dart';

import 'state.dart';

class LoginModuleLogic extends GetxController {
  final LoginModuleState state = LoginModuleState();
}
