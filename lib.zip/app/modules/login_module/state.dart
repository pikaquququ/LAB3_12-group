class LoginModuleState {
  LoginModuleState() {
    ///Initialize variables
  }
}
