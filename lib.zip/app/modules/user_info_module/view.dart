import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class UserInfoModulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<UserInfoModuleLogic>();
    final state = Get.find<UserInfoModuleLogic>().state;

    return Container();
  }
}
