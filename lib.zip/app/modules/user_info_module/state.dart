class UserInfoModuleState {
  UserInfoModuleState() {
    ///Initialize variables
  }
}
