import 'package:get/get.dart';

import 'state.dart';

class UserInfoModuleLogic extends GetxController {
  final UserInfoModuleState state = UserInfoModuleState();
}
