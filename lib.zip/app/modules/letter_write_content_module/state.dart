import 'package:flutter/cupertino.dart';

class LetterWriteContentModuleState {
  late TextEditingController receiver;
dynamic receiverData;
  LetterWriteContentModuleState() {
    ///Initialize variables

    receiver = TextEditingController();
  }
}
