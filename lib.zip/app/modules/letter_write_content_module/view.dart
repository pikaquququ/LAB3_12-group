import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/data/model/mail_draft.dart';
import 'package:ffpo_app/app/global_widgets/page_head.dart';
import 'package:ffpo_app/app/global_widgets/text_editor.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'logic.dart';

class LetterWriteContentModulePage extends StatelessWidget {
  LetterWriteContentModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<LetterWriteContentModuleLogic>();
    final state = Get.find<LetterWriteContentModuleLogic>().state;

    TextEditingController textEditingController = TextEditingController();
    return SafeArea(
        child: Scaffold(
            body: Stack(alignment: Alignment.center, children: [
      Positioned(left: 20.w, top: 21.h, child: const PageHead(title: "信件撰写", type: "secondary")),
      Positioned(
          top: 100.h,
          child: Container(
              width: 350.w,
              height: 55.h,
              decoration: BoxDecoration(color: const Color(0xff509296), borderRadius: BorderRadius.circular(22.5.h)),
              child: Row(children: [
                SizedBox(width: 30.w),
                Text("To", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24.sp, color: Colors.white)),
                SizedBox(width: 20.w),
                const Text(":", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                SizedBox(width: 20.w),
                SizedBox(
                    width: 234.w,
                    child: TextField(
                        enabled: false,
                        controller: state.receiver,
                        style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                        decoration: InputDecoration(
                            // suffix: Icon(Icons.add),
                            suffixIcon: Container(
                                width: 40.h,
                                height: 40.h,
                                child: Center(
                                    child: ClipOval(
                                  child:
                                      Container(width: 40.h, height: 40.h, color: Colors.white, child: Icon(Icons.add)),
                                ))),
                            border: InputBorder.none,
                            hintText: "选择收件人",
                            hintStyle: TextStyle(color: Colors.white))))
              ]))),
      Positioned(
          top: 203.h,
          child: TextEditor(
              maxLine: 13,
              controller: textEditingController,
              fontSize: 21.sp,
              width: 350.w,
              height: 600.h,
              borderRadius: BorderRadius.circular(40.h))),
      Positioned(
          bottom: 25.h,
          child: GestureDetector(
            onTap: () {
              final ctl = Get.find<FFPOController>();
              MailDraft mailDraft = MailDraft();
              mailDraft.msg = textEditingController.text;
              mailDraft.getUserId = state.receiverData["sendUserId"];
              mailDraft.sendUserId = ctl.user.id;
              mailDraft.title = "";
              mailDraft.isPublic = 1;
              mailDraft.id = "";
              Get.toNamed(Routes.LETTER_WRITE_STAMP, arguments: mailDraft);
            },
            child: Container(
                width: 150.w,
                height: 60.h,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30.h),
                    color: Colors.white,
                    boxShadow: const [BoxShadow(color: Colors.grey, offset: Offset(0, 3), blurRadius: 3)]),
                child: Center(child: Text("下一步"))),
          ))
    ])));
  }
}
