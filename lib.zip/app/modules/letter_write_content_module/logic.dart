import 'package:get/get.dart';

import 'state.dart';

class LetterWriteContentModuleLogic extends GetxController {
  final LetterWriteContentModuleState state = LetterWriteContentModuleState();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    state.receiverData = Get.arguments;

    state.receiver.text = state.receiverData?["sendUserName"] ?? "";
  }
}
