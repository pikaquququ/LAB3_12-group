import 'package:get/get.dart';

import 'logic.dart';

class SettingsModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SettingsModuleLogic());
  }
}
