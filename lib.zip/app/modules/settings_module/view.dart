import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../global_widgets/mtable.dart';
import '../../global_widgets/page_head.dart';
import 'logic.dart';


class SettingsModulePage extends StatelessWidget {
  const SettingsModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<SettingsModuleLogic>();
    final state = Get.find<SettingsModuleLogic>().state;

    return Scaffold(
        body: Stack(alignment: Alignment.center, children: [
      Positioned(left: 20.w, top: 21.h, child: const PageHead(title: "设置", type: "primary")),
      Positioned(
          top: 122.h,
          child: MTable(widgets: [
            Row(children: const [Text("账号管理"), Icon(Icons.arrow_forward_ios)]),
            Row(children: const [Text("信息管理"), Icon(Icons.arrow_forward_ios)]),
            Row(children: const [Text("账号安全"), Icon(Icons.arrow_forward_ios)]),
            Row(children: const [Text("消息通知"), Icon(Icons.arrow_forward_ios)])
          ])),
      for (int i = 1; i <= 3; i++)
        Positioned(top: 122.h + 70.h * i, child: Container(width: 360.w, height: 1, color: Colors.white)),
      Positioned(
          top: 473.h,
          child: MTable(widgets: [
            Row(children: const [Text("账号管理"), Icon(Icons.arrow_forward_ios)]),
            Row(children: const [Text("信息管理"), Icon(Icons.arrow_forward_ios)]),
            Row(children: const [Text("账号安全"), Icon(Icons.arrow_forward_ios)]),
            Row(children: const [Text("消息通知"), Icon(Icons.arrow_forward_ios)])
          ]))
    ]));
  }
}
