class SettingsModuleState {
  SettingsModuleState() {
    ///Initialize variables
  }
}
