import 'package:ffpo_app/app/data/model/mail.dart';
import 'package:ffpo_app/app/data/model/stamp_detail.dart';
import 'package:ffpo_app/app/data/model/user.dart';
import 'package:ffpo_app/app/data/model/user_param.dart';
import 'package:ffpo_app/app/data/provider/api_provider.dart';
import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'state.dart';

class StartModuleLogic extends GetxController {
  final StartModuleState state = StartModuleState();

  static Future<String?> getToken() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    return sp.getString("token");
  }

  void login() async {
    UserParam userParam = UserParam(null, state.password.text, 123.2, 222.6, "福建福州", state.phone.text);

    dynamic data = await ApiProvider.login(userParam);
    // EasyLoading.dismiss();
    String? token = data["token"];
    if (token != null) {
      final ctl = Get.find<FFPOController>();
      SharedPreferences sp = await SharedPreferences.getInstance();
      sp.setString("token", token);
      ctl.user = User().fromJson(data["user"]);
      List<Mail> mails = await ApiProvider.getMails();
      ctl.mails.addAll(mails);
      List<StampDetail> stampDetails = await ApiProvider.getStamps();

      ctl.stampDetails.addAll(stampDetails);
      Get.toNamed(Routes.FFPO);
    }
  }
}
