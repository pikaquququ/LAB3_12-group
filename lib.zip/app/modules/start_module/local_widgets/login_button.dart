import 'package:ffpo_app/app/modules/start_module/logic.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../routes/app_pages.dart';

class LoginButton extends StatelessWidget {
  const LoginButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ctl = Get.find<StartModuleLogic>();
    return GestureDetector(
      onTap: () => ctl.login(),
      child: Container(
          width: 320.w,
          height: 60.h,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30.h),
              gradient: const LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [Color(0xff7ab5ba), Color(0xff56a2b4)],
                  stops: [0.3, 1])),
          child: Center(
              child: Text("立即登录",
                  style:
                      TextStyle(fontSize: 24.sp, fontWeight: FontWeight.w400, letterSpacing: 2, color: Colors.white)))),
    );
  }
}
