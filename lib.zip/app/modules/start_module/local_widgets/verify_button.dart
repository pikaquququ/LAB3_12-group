import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/get_core.dart';

import '../../../routes/app_pages.dart';

class VerifyButton extends StatelessWidget {
  const VerifyButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.toNamed(Routes.FFPO),
      child: Container(
          width: 320.w,
          height: 60.h,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30.h),
              gradient: const LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [Color(0xff7ab5ba), Color(0xff56a2b4)],
                  stops: [0.3, 1])),
          child: Center(
              child: Text("短信验证码登录",
                  style:
                      TextStyle(fontSize: 24.sp, fontWeight: FontWeight.w400, letterSpacing: 2, color: Colors.white)))),
    );
  }
}
