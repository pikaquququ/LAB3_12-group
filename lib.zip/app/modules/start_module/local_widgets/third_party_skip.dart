import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ThirdPartySkip extends StatelessWidget {
  const ThirdPartySkip({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        width: 1.sw,
        height: 134.h,
        decoration: BoxDecoration(
            gradient: const LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [Color(0xff68abbb), Color(0xff91c2c6)],
                stops: [0.8, 1]),
            borderRadius: BorderRadius.only(topLeft: Radius.circular(50.h), topRight: Radius.circular(50.h))),
        child: Center(
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          SizedBox(width: 25.w),
          Image.asset("assets/images/WeChat.png", width: 48.h, height: 48.h),
          Image.asset("assets/images/QQ.png", width: 50.h, height: 50.h),
          Image.asset("assets/images/WeiBo.png", width: 70.h, height: 70.h),
          SizedBox(width: 10.w),
        ])));
  }
}
