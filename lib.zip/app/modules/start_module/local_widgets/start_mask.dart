import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class StartMask extends StatelessWidget {
  const StartMask({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1.sw,
      height: 1.sh,
      decoration: const BoxDecoration(color: Color.fromRGBO(0, 0, 0, 0.3)),
    );
  }
}
