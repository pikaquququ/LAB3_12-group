import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../logic.dart';

class PasswordInput extends StatelessWidget {
  const PasswordInput({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // ScreenUtil.init()
    final state = Get.find<StartModuleLogic>().state;
    return Container(
        width: 328.w,
        height: 60.h,
        decoration: const BoxDecoration(
            border: Border(
                bottom: BorderSide(
          width: 3,
          color: Colors.white,
        ))),
        child: TextField(
          controller: state.password,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
              prefixIcon: Icon(
                Icons.remove_red_eye,
                color: Colors.white,
              ),
              labelStyle: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2),
              labelText: "密码",
              border: InputBorder.none),
        ));
  }
}
