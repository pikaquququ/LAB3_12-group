import 'package:flutter/cupertino.dart';

class StartModuleState {
late  TextEditingController phone;
late TextEditingController password;
  StartModuleState() {
    ///Initialize variables
    phone = TextEditingController();
    password = TextEditingController();
  }
}
