import 'package:ffpo_app/app/modules/start_module/local_widgets/login_button.dart';
import 'package:ffpo_app/app/modules/start_module/local_widgets/password_input.dart';
import 'package:ffpo_app/app/modules/start_module/local_widgets/phone_input.dart';
import 'package:ffpo_app/app/modules/start_module/local_widgets/start_mask.dart';
import 'package:ffpo_app/app/modules/start_module/local_widgets/third_party_skip.dart';
import 'package:ffpo_app/app/modules/start_module/local_widgets/verify_button.dart';
import 'package:ffpo_app/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'logic.dart';

class StartModulePage extends StatelessWidget {
  const StartModulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<StartModuleLogic>();
    final state = Get.find<StartModuleLogic>().state;
    double rate = (MediaQuery.of(context).size.height -
            MediaQuery.of(context).padding.top -
            MediaQuery.of(context).padding.bottom) /
        MediaQuery.of(context).size.height;
    ScreenUtil.init(context, designSize: Size(428, rate * 926));
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          decoration:
              const BoxDecoration(image: DecorationImage(image: AssetImage("assets/images/bg.png"), fit: BoxFit.cover)),
          child: Stack(alignment: Alignment.center, children: [
            const Positioned(child: StartMask()),
            Positioned(
                top: 92.h, child: ClipOval(child: Image.asset("assets/images/logo.png", width: 200.h, height: 200.h))),
            Positioned(top: 350.h, child: const PhoneInput()),
            Positioned(top: 410.h, child: const PasswordInput()),
            Positioned(top: 637.h, child: const VerifyButton()),
            Positioned(top: 553.h, child: const LoginButton()),
            Positioned(
                left: 64.w,
                top: 498.h,
                child: GestureDetector(
                    onTap: () => Get.toNamed(Routes.RETRIEVE_PASSWORD),
                    child: Text("忘记密码?",
                        style: TextStyle(
                            fontSize: 16.sp, letterSpacing: 1, fontWeight: FontWeight.bold, color: Colors.white)))),
            Positioned(
                left: 301.w,
                top: 498.h,
                child: GestureDetector(
                    onTap: () => Get.toNamed(Routes.REGISTER),
                    child: Text("注册账号",
                        style: TextStyle(
                            fontSize: 16.sp, letterSpacing: 1, fontWeight: FontWeight.bold, color: Colors.white)))),
            const Positioned(bottom: 0, child: ThirdPartySkip()),
            Positioned(
                top: 804.h,
                child:
                    Text("其他登录方式", style: TextStyle(fontWeight: FontWeight.w400, fontSize: 16.sp, color: Colors.white)))
          ]),
        ));
  }
}
