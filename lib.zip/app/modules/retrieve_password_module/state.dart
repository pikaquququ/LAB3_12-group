import 'package:flutter/material.dart';

class RetrievePasswordModuleState {

  late  TextEditingController password;
  late  TextEditingController passwordRepeat;
  late  TextEditingController phone;
  late  TextEditingController authCode;
  RetrievePasswordModuleState() {
    ///Initialize variables
    password=TextEditingController();
    passwordRepeat=TextEditingController();
    phone=TextEditingController();
    authCode=TextEditingController();
  }
}
