import 'package:get/get.dart';

import 'state.dart';

class RetrievePasswordModuleLogic extends GetxController {
  final RetrievePasswordModuleState state = RetrievePasswordModuleState();
}
