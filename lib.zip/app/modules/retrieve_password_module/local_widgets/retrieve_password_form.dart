import 'package:ffpo_app/app/modules/register_module/local_widgets/register_form_item.dart';
import 'package:ffpo_app/app/modules/register_module/logic.dart';
import 'package:ffpo_app/app/modules/retrieve_password_module/logic.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class RetrievePasswordFormComponent extends StatelessWidget {
  RetrievePasswordFormComponent({Key? key}) : super(key: key);
  final logic = Get.find<RetrievePasswordModuleLogic>();
  final state = Get.find<RetrievePasswordModuleLogic>().state;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: 328.w,
        height: 73.h * 4,
        child: Column(children: [
          RegisterFormItemComponent(label: "手机号", controller: state.phone),
          RegisterFormItemComponent(
              label: "验证码",
              controller: state.authCode,
              suffix: SizedBox(
                  height: 73.h,
                  width: 107.w,
                  child: Center(
                      child: Text("获取验证码",
                          style: TextStyle(
                              fontSize: 20.sp, fontWeight: FontWeight.w400, letterSpacing: 1, color: Colors.white))))),
          RegisterFormItemComponent(label: "新的密码", controller: state.password),
          RegisterFormItemComponent(label: "确认密码", controller: state.passwordRepeat),
        ]));
  }
}
