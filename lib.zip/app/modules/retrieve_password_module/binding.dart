import 'package:get/get.dart';

import 'logic.dart';

class RetrievePasswordModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RetrievePasswordModuleLogic());
  }
}
