class StampsStoreModuleState {
  StampsStoreModuleState() {
    ///Initialize variables
  }
}
