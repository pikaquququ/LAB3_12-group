import 'package:get/get.dart';

import 'logic.dart';

class StampsStoreModuleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => StampsStoreModuleLogic());
  }
}
