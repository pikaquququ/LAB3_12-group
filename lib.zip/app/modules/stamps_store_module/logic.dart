import 'package:get/get.dart';

import 'state.dart';

class StampsStoreModuleLogic extends GetxController {
  final StampsStoreModuleState state = StampsStoreModuleState();
}
