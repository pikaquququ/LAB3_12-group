import 'package:flutter/material.dart';
/**
 * GetX Template Generator - fb.com/htngu.99
 * */

const Color exampleColor = Colors.white;
const Color mediumGrey = Color(0xffD9D9D9);
const Color navyBlue = Color(0xff509296);
