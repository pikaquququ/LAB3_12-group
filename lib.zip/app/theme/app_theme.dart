import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
/**
 * GetX Template Generator - fb.com/htngu.99
 * */

final ThemeData appThemeData = ThemeData(
  primarySwatch: Colors.blue,
  visualDensity: VisualDensity.adaptivePlatformDensity,
  fontFamily: "kaiti"
  // textTheme: GoogleFonts.notoSansMonoTextTheme(),
);
