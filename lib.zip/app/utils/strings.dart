/**
 * GetX Template Generator - fb.com/htngu.99
 * */

String home = 'Home';