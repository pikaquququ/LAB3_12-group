import 'package:ffpo_app/app/modules/f_f_p_o_module/f_f_p_o_controller.dart';
import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class PageHead extends StatelessWidget {
  const PageHead({Key? key, required this.title, required this.type}) : super(key: key);
  final String title;
  final String type;

  @override
  Widget build(BuildContext context) {
    final ctl = Get.find<FFPOController>();
    return Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
        width: 250.w,
        child: Row(children: [
          GestureDetector(
              onTap: () => type == "primary" ? ctl.toggleDrawer() : Get.back(),
              child: Container(
                  width: 40.h,
                  height: 40.h,
                  decoration: const BoxDecoration(color: navyBlue, shape: BoxShape.circle),
                  child: Icon(Icons.arrow_back_ios_outlined, color: Colors.white, size: 33.h))),
          SizedBox(width: 20.w),
          Text(title, style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1, fontSize: 33.sp))
        ]));
  }
}
