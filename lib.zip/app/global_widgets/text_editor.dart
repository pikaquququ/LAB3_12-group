import 'package:ffpo_app/app/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TextEditor extends StatelessWidget {
  const TextEditor(
      {Key? key,
      required this.maxLine,
      required this.controller,
      required this.fontSize,
      required this.width,
      required this.height,
      required this.borderRadius,
      this.enabled = true})
      : super(key: key);
  final int maxLine;
  final TextEditingController controller;
  final double fontSize;
  final double width;
  final double height;
  final BorderRadiusGeometry borderRadius;
  final bool? enabled;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: width,
        height: height,
        padding: EdgeInsets.symmetric(horizontal: 40.w),
        // rgba(173, 207, 200, 0.8)
        decoration: BoxDecoration(borderRadius: borderRadius, color: Color.fromRGBO(173, 207, 200, 0.8)),
        child: Stack(
          children: [
            for (int i = 0; i < maxLine; i++)
              Container(
                  width: double.infinity,
                  margin: EdgeInsets.only(top: (i + 1) * fontSize * 2),
                  height: 1,
                  color: Colors.white),
            TextField(
                maxLines: 11,
                cursorColor: navyBlue,
                enabled: enabled,
                style: TextStyle(fontSize: fontSize, height: 2, color: Colors.white),
                decoration: null,
                controller: controller)
          ],
        ));
  }
}
