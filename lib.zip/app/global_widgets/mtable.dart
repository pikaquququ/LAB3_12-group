
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class MTable extends StatelessWidget {
  const MTable({Key? key, required this.widgets}) : super(key: key);
  final List<Widget> widgets;

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Container(
          width: 360.w,
          height: widgets.length * 70.h,
          decoration:
          BoxDecoration(color: const Color.fromRGBO(173, 207, 200, 0.8), borderRadius: BorderRadius.circular(30.h)),
          child: Column(children: [
            for (int i = 0; i < widgets.length; i++) SizedBox(width: 360.w, height: 70.h, child: widgets[i])
          ])),
      for (int i = 1; i <= widgets.length; i++)
        Positioned(top: 70.h * i, child: Container(width: 360.w, height: 2, color: Colors.white))
    ]);
  }
}