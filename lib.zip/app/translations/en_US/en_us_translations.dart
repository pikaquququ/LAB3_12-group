import '../../../app/utils/strings.dart';
/**
 * GetX Template Generator - fb.com/htngu.99
 * */

final Map<String, String> enUs = {
  'hi': 'Hello',
  home: "Home",
};