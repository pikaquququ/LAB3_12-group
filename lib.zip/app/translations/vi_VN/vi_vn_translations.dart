import '../../../app/utils/strings.dart';
/**
 * GetX Template Generator - fb.com/htngu.99
 * */

final Map<String, String> viVn = {
  'hi': 'Xin chào',
  home: 'Trang chủ',
};